package com.example.exovideoapp.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.work.WorkManager
import com.example.ExoPlayerUtils
import com.example.exovideoapp.VideoApp
import com.example.exovideoapp.databinding.ActivityMainBinding
import com.example.exovideoapp.viewmodel.MainActivityViewModel
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.upstream.DefaultDataSource
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.upstream.HttpDataSource
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import com.google.android.exoplayer2.upstream.cache.SimpleCache

class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding

    private lateinit var mHttpDataSourceFactory: HttpDataSource.Factory
    private lateinit var mDefaultDataSourceFactory: DefaultDataSource.Factory
    private lateinit var exoPlayer: ExoPlayer
    private lateinit var viewModel: MainActivityViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainActivityViewModel::class.java]

        val workManager = WorkManager.getInstance(applicationContext)
        viewModel.schedulePreloadWork(ExoPlayerUtils.videoUrl,workManager)

        mHttpDataSourceFactory = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)

        this.mDefaultDataSourceFactory = DefaultDataSource.Factory(
            applicationContext, mHttpDataSourceFactory
        )

        val cache: SimpleCache = VideoApp.cache

        val cacheFactory = viewModel.getCacheDataSourceFactory(cache, mHttpDataSourceFactory)

         cacheFactory?.let {
             initializePrepareExoPlayer(cacheFactory)
         }
    }


    private fun initializePrepareExoPlayer(cacheFactory: CacheDataSource.Factory) {
        exoPlayer = ExoPlayer.Builder(applicationContext).setMediaSourceFactory(DefaultMediaSourceFactory(cacheFactory)).build()
        binding.playerView.player = exoPlayer
        exoPlayer.playWhenReady = true
        exoPlayer.seekTo(0, 0 )
        viewModel.getMediaSource(cacheFactory, ExoPlayerUtils.videoUrl)
            ?.let { exoPlayer.setMediaSource(it, true) }
        exoPlayer.prepare()
    }

}