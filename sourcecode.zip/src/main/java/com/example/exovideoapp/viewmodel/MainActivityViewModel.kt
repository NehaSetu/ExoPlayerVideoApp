package com.example.exovideoapp.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.work.ExistingWorkPolicy
import androidx.work.WorkManager
import com.example.exovideoapp.worker.VideoPreloaderWorker
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.MediaSource
import com.google.android.exoplayer2.source.ProgressiveMediaSource
import com.google.android.exoplayer2.upstream.DataSource
import com.google.android.exoplayer2.upstream.HttpDataSource
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import com.google.android.exoplayer2.upstream.cache.SimpleCache

class MainActivityViewModel:ViewModel() {

    fun schedulePreloadWork(videoUrl: String, workManager: WorkManager) : Boolean {

        return if (videoUrl.isNotEmpty()) {
            val videoPreloadWorker = VideoPreloaderWorker.buildWorkRequest(videoUrl)
            workManager.enqueueUniqueWork(
                "VideoPreloaderWorker",
                ExistingWorkPolicy.KEEP,
                videoPreloadWorker
            )
            false
        } else {
            true
        }

    }

    fun getMediaSource (mCacheDataSourceFactory : DataSource.Factory?, videoUrl: String) : MediaSource? {
        val videoUri = Uri.parse(videoUrl)
        val mediaItem = MediaItem.fromUri(videoUri)
        return mCacheDataSourceFactory?.let { ProgressiveMediaSource.Factory(it).createMediaSource(mediaItem) }
    }

    fun getCacheDataSourceFactory(cache: SimpleCache?, mHttpDataSourceFactory: HttpDataSource.Factory) : CacheDataSource.Factory? {

        return cache?.let {
            CacheDataSource.Factory()
                .setCache(it)
                .setUpstreamDataSourceFactory(mHttpDataSourceFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        }

    }
}