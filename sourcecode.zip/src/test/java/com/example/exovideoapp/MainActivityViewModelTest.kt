package com.example.exovideoapp

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.WorkManager
import com.example.ExoPlayerUtils
import com.example.exovideoapp.viewmodel.MainActivityViewModel
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.upstream.cache.SimpleCache
import io.mockk.mockk
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TestRule
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class MainActivityViewModelTest {

    @get:Rule
    val rule: TestRule = InstantTaskExecutorRule()
    private lateinit var viewModel : MainActivityViewModel
     private val mHttpDataSourceFactory = DefaultHttpDataSource.Factory().setAllowCrossProtocolRedirects(true)
    private  var simpleCache  :SimpleCache = mockk()
    private var workManager : WorkManager = mockk()

    @Before
    fun setup() {
        viewModel = MainActivityViewModel()

     }

    @Test
    fun whenVideoUrlEmptyNotEnqueWorkOrder () {
        Assert.assertEquals(true, viewModel.schedulePreloadWork("", workManager))
    }

    @Test
    fun getInvalidCacheDataSourceFactory () {
        Assert.assertNull( viewModel.getCacheDataSourceFactory(null, mHttpDataSourceFactory))
     }

    @Test
    fun getValidCacheDataSourceFactory () {
        Assert.assertNotNull( viewModel.getCacheDataSourceFactory(simpleCache, mHttpDataSourceFactory))
    }

}